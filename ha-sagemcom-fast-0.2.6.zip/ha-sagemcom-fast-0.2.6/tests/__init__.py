"""Tests for the Sagemcom F@st integration."""
